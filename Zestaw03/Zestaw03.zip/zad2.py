L = [3,5,4]
# L = L.sort()
L.sort()

#x, y = 1, 2, 3
x, y = 1, 2.3

# x = 1, 2, 3 ; x[1] = 4
x = [1, 2, 3] ; x[1] = 4

# x = [1, 2, 3] ; x[3] = 4
x = [1, 2, 3] ; x[2] = 4

# X = "abc" ; X.append("d")
X = ["abc"] ; X.append("d")

# L = list(map(pow, range(8)))
L = list(map(pow, [i for i in range(8)], [2 for i in range(8)]))