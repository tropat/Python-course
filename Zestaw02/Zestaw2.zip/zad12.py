line = "przykladowy tekst"
napis = line[:3]
print(napis)
napis = line[6:]
print(napis)