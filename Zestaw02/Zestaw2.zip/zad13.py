line = "jakis przykladowy tekst"
tab = [len(wyraz) for wyraz in line.split()]
print(sum(tab))
