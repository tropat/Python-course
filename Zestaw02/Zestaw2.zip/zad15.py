L = [1,2,5,2,3,6,2,7]

napis = ''

for i in L:
    napis += str(i)

print(napis)