line = """jakis napis\n
przykladowy
wielowierszowy"""

ile = 0

for wyraz in line.split():
    ile += 1

print(ile)