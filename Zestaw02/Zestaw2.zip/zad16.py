line = "jakis tekst GvR przykladowy"
napis1 = "GvR"
napis2 = "Guido van Rossum"

print(line.replace(napis1, napis2))